﻿namespace Algorithms.Search.AStar
{
    /// <summary>
    ///     The states the nodes can have.
    /// </summary>
    public enum NodeState
    {
        /// <summary>
        ///     TODO.
        /// </summary>
        Unconsidered = 0,

        /// <summary>
        ///     TODO.
        /// </summary>
        Open = 1,

        /// <summary>
        ///     TODO.
        /// </summary>
        Closed = 2,
    }
}
